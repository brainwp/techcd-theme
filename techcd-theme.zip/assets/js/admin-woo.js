jQuery(document).ready(function($) {
	$('.options_group.pricing').css('display','none');
    $('ul .shipping_tab').css('display','none');
	$('#_regular_price').attr('value','1');
	$('td.is_in_stock').css('display','none');
	$('th.is_in_stock').css('display','none');
	$('#price').css('display','none');
	$('td.price').css('display','none');
	$('th.column-price').css('display','none');
	$('th.column-is_in_stock').css('display','none');
	$('td.line_cost').css('display','none');
	$('th.line_cost').css('display','none');
	$('table.wc-order-totals').css('display','none');
	$('p.add-items').css('display','none');
	$('th.column-shipping_address').css('display','none');
	$('td.column-shipping_address').css('display','none');
	$('th.column-order_total').css('display','none');
	$('td.column-order_total').css('display','none');
	if($('input[name=post_destacado]:checked').val() == 'true'){
		$('#acf_sub_title').css('display','block');
	}
	$('input[name=post_destacado]').on('click',function(){
		if($('input[name=post_destacado]:checked').val() == 'true'){
			$('#acf_sub_title').css('display','block');
	    }
	    else{
	    	$('#acf_sub_title').css('display','none');
	    }
	})

});
