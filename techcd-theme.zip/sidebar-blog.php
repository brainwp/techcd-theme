<?php
/*sidebar blog*/
dynamic_sidebar( 'blog_sidebar' );
?>
